--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: aumenta_posti_disponibili(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.aumenta_posti_disponibili() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
		update tratta
    set posti_disponibili=posti_disponibili+1
    where old.tratta=id;
	return old;

	END;
$$;


ALTER FUNCTION public.aumenta_posti_disponibili() OWNER TO postgres;

--
-- Name: diminuisci_posti_disponibili(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.diminuisci_posti_disponibili() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    update tratta
    set posti_disponibili=posti_disponibili-1
    where new.tratta=id;
	return new;
END;
$$;


ALTER FUNCTION public.diminuisci_posti_disponibili() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin (
    username character varying NOT NULL,
    cognome character varying NOT NULL,
    nome character varying NOT NULL,
    password character varying NOT NULL
);


ALTER TABLE public.admin OWNER TO postgres;

--
-- Name: biglietto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.biglietto (
    numero character varying NOT NULL,
    tratta character varying NOT NULL,
    posto integer NOT NULL,
    data_ora_acquisto timestamp without time zone NOT NULL,
    scadenza timestamp without time zone NOT NULL,
    utente character varying,
    nome character varying,
    cognome character varying,
    cf character(16) DEFAULT NULL::bpchar
);


ALTER TABLE public.biglietto OWNER TO postgres;

--
-- Name: biglietto_transazione; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.biglietto_transazione (
    id_transazione integer NOT NULL,
    numero_biglietto character varying NOT NULL
);


ALTER TABLE public.biglietto_transazione OWNER TO postgres;

--
-- Name: buono; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.buono (
    codice character varying NOT NULL,
    nome character varying NOT NULL,
    valore money NOT NULL
);


ALTER TABLE public.buono OWNER TO postgres;

--
-- Name: carta_di_pagamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carta_di_pagamento (
    numero character(16) NOT NULL,
    nome character varying NOT NULL,
    cvc character(3) NOT NULL,
    data_di_scadenza date NOT NULL
);


ALTER TABLE public.carta_di_pagamento OWNER TO postgres;

--
-- Name: conto_corrente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conto_corrente (
    iban character(16) NOT NULL,
    nome character varying NOT NULL,
    banca character varying NOT NULL
);


ALTER TABLE public.conto_corrente OWNER TO postgres;

--
-- Name: conversazione; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversazione (
    nome character varying NOT NULL,
    username_admin character varying,
    email_utente character varying,
    nome_venditore character varying
);


ALTER TABLE public.conversazione OWNER TO postgres;

--
-- Name: messaggio_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.messaggio_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.messaggio_id OWNER TO postgres;

--
-- Name: messaggio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messaggio (
    id bigint DEFAULT nextval('public.messaggio_id'::regclass) NOT NULL,
    testo character varying,
    mittente character varying NOT NULL,
    data timestamp without time zone NOT NULL,
    conversazione character varying NOT NULL
);


ALTER TABLE public.messaggio OWNER TO postgres;

--
-- Name: metodo_di_pagamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.metodo_di_pagamento (
    nome character varying NOT NULL,
    wallet bigint NOT NULL
);


ALTER TABLE public.metodo_di_pagamento OWNER TO postgres;

--
-- Name: pagamento_buono_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pagamento_buono_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 9999999
    CACHE 1;


ALTER SEQUENCE public.pagamento_buono_id OWNER TO postgres;

--
-- Name: pagamento_carta_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pagamento_carta_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 9999999
    CACHE 1;


ALTER SEQUENCE public.pagamento_carta_id OWNER TO postgres;

--
-- Name: pagamento_conto_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pagamento_conto_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 9999999
    CACHE 1;


ALTER SEQUENCE public.pagamento_conto_id OWNER TO postgres;

--
-- Name: tappe; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tappe (
    tratta character varying NOT NULL,
    citta1 character varying,
    citta2 character varying,
    citta3 character varying,
    citta4 character varying,
    citta5 character varying,
    citta6 character varying,
    citta7 character varying,
    citta8 character varying,
    citta9 character varying,
    citta10 character varying
);


ALTER TABLE public.tappe OWNER TO postgres;

--
-- Name: transazione_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transazione_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transazione_id OWNER TO postgres;

--
-- Name: transazione; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transazione (
    id bigint DEFAULT nextval('public.transazione_id'::regclass) NOT NULL,
    valore money NOT NULL,
    data_ora timestamp without time zone NOT NULL,
    metodo_pagamento character varying,
    wallet bigint NOT NULL
);


ALTER TABLE public.transazione OWNER TO postgres;

--
-- Name: tratta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tratta (
    id character varying NOT NULL,
    partenza character varying NOT NULL,
    destinazione character varying NOT NULL,
    tipo_mezzo character(5) NOT NULL,
    capienza integer NOT NULL,
    data_ora timestamp without time zone NOT NULL,
    posti_disponibili integer NOT NULL,
    nome_venditore character varying NOT NULL,
    sconto integer,
    numero_biglietti_scontati integer DEFAULT 0 NOT NULL,
    prezzo money DEFAULT 0 NOT NULL
);


ALTER TABLE public.tratta OWNER TO postgres;

--
-- Name: COLUMN tratta.tipo_mezzo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tratta.tipo_mezzo IS 'AEREO, TRENO, BUS';


--
-- Name: tratta_aerei_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tratta_aerei_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tratta_aerei_id OWNER TO postgres;

--
-- Name: tratta_bus_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tratta_bus_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tratta_bus_id OWNER TO postgres;

--
-- Name: tratta_treni_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tratta_treni_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tratta_treni_id OWNER TO postgres;

--
-- Name: utente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.utente (
    indirizzo_email character varying NOT NULL,
    cognome character varying NOT NULL,
    nome character varying NOT NULL,
    data_nascita date NOT NULL,
    password character varying NOT NULL,
    numero_telefono character varying NOT NULL,
    id_wallet bigint NOT NULL,
    ban boolean DEFAULT false NOT NULL
);


ALTER TABLE public.utente OWNER TO postgres;

--
-- Name: venditore; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.venditore (
    "nome_società" character varying NOT NULL,
    password character varying NOT NULL,
    indirizzo_email character varying NOT NULL,
    id_wallet bigint NOT NULL,
    ban boolean DEFAULT false NOT NULL
);


ALTER TABLE public.venditore OWNER TO postgres;

--
-- Name: wallet_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wallet_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wallet_id OWNER TO postgres;

--
-- Name: wallet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wallet (
    id bigint DEFAULT nextval('public.wallet_id'::regclass) NOT NULL,
    saldo money DEFAULT 0 NOT NULL,
    puntiacquisto numeric DEFAULT 0 NOT NULL
);


ALTER TABLE public.wallet OWNER TO postgres;

--
-- Data for Name: admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin (username, cognome, nome, password) FROM stdin;
\.
COPY public.admin (username, cognome, nome, password) FROM '$$PATH$$/4406.dat';

--
-- Data for Name: biglietto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.biglietto (numero, tratta, posto, data_ora_acquisto, scadenza, utente, nome, cognome, cf) FROM stdin;
\.
COPY public.biglietto (numero, tratta, posto, data_ora_acquisto, scadenza, utente, nome, cognome, cf) FROM '$$PATH$$/4416.dat';

--
-- Data for Name: biglietto_transazione; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.biglietto_transazione (id_transazione, numero_biglietto) FROM stdin;
\.
COPY public.biglietto_transazione (id_transazione, numero_biglietto) FROM '$$PATH$$/4429.dat';

--
-- Data for Name: buono; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.buono (codice, nome, valore) FROM stdin;
\.
COPY public.buono (codice, nome, valore) FROM '$$PATH$$/4412.dat';

--
-- Data for Name: carta_di_pagamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.carta_di_pagamento (numero, nome, cvc, data_di_scadenza) FROM stdin;
\.
COPY public.carta_di_pagamento (numero, nome, cvc, data_di_scadenza) FROM '$$PATH$$/4413.dat';

--
-- Data for Name: conto_corrente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conto_corrente (iban, nome, banca) FROM stdin;
\.
COPY public.conto_corrente (iban, nome, banca) FROM '$$PATH$$/4414.dat';

--
-- Data for Name: conversazione; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversazione (nome, username_admin, email_utente, nome_venditore) FROM stdin;
\.
COPY public.conversazione (nome, username_admin, email_utente, nome_venditore) FROM '$$PATH$$/4422.dat';

--
-- Data for Name: messaggio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messaggio (id, testo, mittente, data, conversazione) FROM stdin;
\.
COPY public.messaggio (id, testo, mittente, data, conversazione) FROM '$$PATH$$/4423.dat';

--
-- Data for Name: metodo_di_pagamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.metodo_di_pagamento (nome, wallet) FROM stdin;
\.
COPY public.metodo_di_pagamento (nome, wallet) FROM '$$PATH$$/4411.dat';

--
-- Data for Name: tappe; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tappe (tratta, citta1, citta2, citta3, citta4, citta5, citta6, citta7, citta8, citta9, citta10) FROM stdin;
\.
COPY public.tappe (tratta, citta1, citta2, citta3, citta4, citta5, citta6, citta7, citta8, citta9, citta10) FROM '$$PATH$$/4425.dat';

--
-- Data for Name: transazione; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transazione (id, valore, data_ora, metodo_pagamento, wallet) FROM stdin;
\.
COPY public.transazione (id, valore, data_ora, metodo_pagamento, wallet) FROM '$$PATH$$/4417.dat';

--
-- Data for Name: tratta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tratta (id, partenza, destinazione, tipo_mezzo, capienza, data_ora, posti_disponibili, nome_venditore, sconto, numero_biglietti_scontati, prezzo) FROM stdin;
\.
COPY public.tratta (id, partenza, destinazione, tipo_mezzo, capienza, data_ora, posti_disponibili, nome_venditore, sconto, numero_biglietti_scontati, prezzo) FROM '$$PATH$$/4415.dat';

--
-- Data for Name: utente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.utente (indirizzo_email, cognome, nome, data_nascita, password, numero_telefono, id_wallet, ban) FROM stdin;
\.
COPY public.utente (indirizzo_email, cognome, nome, data_nascita, password, numero_telefono, id_wallet, ban) FROM '$$PATH$$/4407.dat';

--
-- Data for Name: venditore; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.venditore ("nome_società", password, indirizzo_email, id_wallet, ban) FROM stdin;
\.
COPY public.venditore ("nome_società", password, indirizzo_email, id_wallet, ban) FROM '$$PATH$$/4408.dat';

--
-- Data for Name: wallet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wallet (id, saldo, puntiacquisto) FROM stdin;
\.
COPY public.wallet (id, saldo, puntiacquisto) FROM '$$PATH$$/4409.dat';

--
-- Name: messaggio_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.messaggio_id', 16, true);


--
-- Name: pagamento_buono_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pagamento_buono_id', 17, true);


--
-- Name: pagamento_carta_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pagamento_carta_id', 5, true);


--
-- Name: pagamento_conto_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pagamento_conto_id', 1, true);


--
-- Name: transazione_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transazione_id', 122, true);


--
-- Name: tratta_aerei_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tratta_aerei_id', 71, true);


--
-- Name: tratta_bus_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tratta_bus_id', 26, true);


--
-- Name: tratta_treni_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tratta_treni_id', 40, true);


--
-- Name: wallet_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wallet_id', 11, true);


--
-- Name: admin admin_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT admin_pk PRIMARY KEY (username);


--
-- Name: biglietto biglietto_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.biglietto
    ADD CONSTRAINT biglietto_pk PRIMARY KEY (numero);


--
-- Name: biglietto_transazione biglietto_transazione_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.biglietto_transazione
    ADD CONSTRAINT biglietto_transazione_pk PRIMARY KEY (id_transazione, numero_biglietto);


--
-- Name: buono buono_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buono
    ADD CONSTRAINT buono_pk PRIMARY KEY (codice, nome);


--
-- Name: carta_di_pagamento carta_di_pagamento_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carta_di_pagamento
    ADD CONSTRAINT carta_di_pagamento_pk PRIMARY KEY (numero, nome);


--
-- Name: conto_corrente conto_corrente_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conto_corrente
    ADD CONSTRAINT conto_corrente_pk PRIMARY KEY (iban, nome);


--
-- Name: conversazione conversazione_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversazione
    ADD CONSTRAINT conversazione_pk PRIMARY KEY (nome);


--
-- Name: messaggio messaggio_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messaggio
    ADD CONSTRAINT messaggio_pk PRIMARY KEY (id);


--
-- Name: metodo_di_pagamento metodo_di_pagamento_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.metodo_di_pagamento
    ADD CONSTRAINT metodo_di_pagamento_pk PRIMARY KEY (nome);


--
-- Name: tappe tappe_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tappe
    ADD CONSTRAINT tappe_pk PRIMARY KEY (tratta);


--
-- Name: transazione transazione_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transazione
    ADD CONSTRAINT transazione_pk PRIMARY KEY (id);


--
-- Name: tratta tratta_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tratta
    ADD CONSTRAINT tratta_pk PRIMARY KEY (id);


--
-- Name: utente utente_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utente
    ADD CONSTRAINT utente_pk PRIMARY KEY (indirizzo_email);


--
-- Name: venditore venditore_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.venditore
    ADD CONSTRAINT venditore_pk PRIMARY KEY ("nome_società");


--
-- Name: venditore venditore_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.venditore
    ADD CONSTRAINT venditore_un UNIQUE (indirizzo_email);


--
-- Name: wallet wallet_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wallet
    ADD CONSTRAINT wallet_pk PRIMARY KEY (id);


--
-- Name: biglietto trigger_aumenta_posti_disponibili; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_aumenta_posti_disponibili AFTER DELETE ON public.biglietto FOR EACH ROW EXECUTE FUNCTION public.aumenta_posti_disponibili();


--
-- Name: biglietto trigger_diminuisci_posti_disponibili; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_diminuisci_posti_disponibili BEFORE INSERT ON public.biglietto FOR EACH ROW EXECUTE FUNCTION public.diminuisci_posti_disponibili();


--
-- Name: biglietto biglietto_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.biglietto
    ADD CONSTRAINT biglietto_fk FOREIGN KEY (tratta) REFERENCES public.tratta(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: biglietto biglietto_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.biglietto
    ADD CONSTRAINT biglietto_fk_1 FOREIGN KEY (utente) REFERENCES public.utente(indirizzo_email) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: biglietto_transazione biglietto_transazione_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.biglietto_transazione
    ADD CONSTRAINT biglietto_transazione_fk FOREIGN KEY (numero_biglietto) REFERENCES public.biglietto(numero) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: biglietto_transazione biglietto_transazione_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.biglietto_transazione
    ADD CONSTRAINT biglietto_transazione_fk_1 FOREIGN KEY (id_transazione) REFERENCES public.transazione(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: buono buono_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buono
    ADD CONSTRAINT buono_fk FOREIGN KEY (nome) REFERENCES public.metodo_di_pagamento(nome) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: carta_di_pagamento carta_di_pagamento_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carta_di_pagamento
    ADD CONSTRAINT carta_di_pagamento_fk FOREIGN KEY (nome) REFERENCES public.metodo_di_pagamento(nome) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conto_corrente conto_corrente_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conto_corrente
    ADD CONSTRAINT conto_corrente_fk FOREIGN KEY (nome) REFERENCES public.metodo_di_pagamento(nome) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversazione conversazione_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversazione
    ADD CONSTRAINT conversazione_fk FOREIGN KEY (username_admin) REFERENCES public.admin(username) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversazione conversazione_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversazione
    ADD CONSTRAINT conversazione_fk_1 FOREIGN KEY (nome_venditore) REFERENCES public.venditore("nome_società") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversazione conversazione_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversazione
    ADD CONSTRAINT conversazione_fk_2 FOREIGN KEY (email_utente) REFERENCES public.utente(indirizzo_email) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messaggio messaggio_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messaggio
    ADD CONSTRAINT messaggio_fk FOREIGN KEY (conversazione) REFERENCES public.conversazione(nome) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: metodo_di_pagamento metodo_di_pagamento_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.metodo_di_pagamento
    ADD CONSTRAINT metodo_di_pagamento_fk FOREIGN KEY (wallet) REFERENCES public.wallet(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tappe tappe_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tappe
    ADD CONSTRAINT tappe_fk FOREIGN KEY (tratta) REFERENCES public.tratta(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transazione transazione_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transazione
    ADD CONSTRAINT transazione_fk FOREIGN KEY (metodo_pagamento) REFERENCES public.metodo_di_pagamento(nome);


--
-- Name: transazione transazione_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transazione
    ADD CONSTRAINT transazione_fk_1 FOREIGN KEY (wallet) REFERENCES public.wallet(id);


--
-- Name: tratta tratta_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tratta
    ADD CONSTRAINT tratta_fk FOREIGN KEY (nome_venditore) REFERENCES public.venditore("nome_società") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: utente utente_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utente
    ADD CONSTRAINT utente_fk FOREIGN KEY (id_wallet) REFERENCES public.wallet(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: venditore venditore_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.venditore
    ADD CONSTRAINT venditore_fk FOREIGN KEY (id_wallet) REFERENCES public.wallet(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

